
function ajaxGetRequest(route, call){
    let request = new XMLHttpRequest();
    request.onreadystatechange = function(){
        if (this.readyState === 4 && this.status === 200){
            call(this.response);
        }
    };
    request.open("GET", route);
    request.send();
}

function ajaxPostRequest(route, info, call){
    let request = new XMLHttpRequest();
    request.onreadystatechange = function(){
        if (this.readyState === 4 && this.status === 200){
            call(this.response);
        }
    };
    request.open("POST", route);
    request.send(info);
}