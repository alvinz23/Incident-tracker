#Part 2
def list_dic_gen(x,y):
  newList=[]
  for i in y:
    newDic={}
    for k in range(len(x)):#the keys 
      newDic[x[k]]= i[k]
    newList.append(newDic)
  return newList


def read_values(x):
  import csv 
  f=open(x,"r")
  reader=csv.reader(f)
  next(reader,None)
  newList=[]
  for line in reader:
    newList.append(line)
  return newList

def list_gen(x,y):
  result=[]
  for i in x: 
    list=[]
    for k in y: 
      list.append(i[k])
    result.append(list)
  return result

def write_values(x,y):
  import csv 
  f=open(y,"a")
  for i in x:
    writer=csv.writer(f)
    writer.writerow(i)


#Part 3 
def split_date(x):
    newList=[]
    newList.append(int(x[0:4]))
    newList.append(int(x[5:7]))
    return newList


def fix_data(data,key):
  for i in data:
    year,month = split_date(i[key])
    i['year']=year
    i['month']=month
  return data 

from urllib.request import urlopen
import json
def json_loader(x):
  response = urlopen(x)
  json_data = json.loads(response.read())
  return json_data
  
def make_values_numeric(x, dic):
    for string in x:
        if string in dic:
            dic[string] = int(dic[string])
    return dic



import csv 
def save_data(dicts, keys, filename):
  with open (filename,"w") as f:
    csvwriter=csv.writer(f)
    csvwriter.writerow(keys)
    for x in dicts:
      newList=[]
      for key in keys:
        newList.append(x[key])
      csvwriter.writerow(newList)

def load_data(filename):
  import csv
  newList = []
  with open(filename, "r", newline="") as csvfile:
    csvreader = csv.DictReader(csvfile)
    for row in csvreader:
      newList.append(row)
    return newList
