#Part 1
def gen_dictionary(dictData,keyValues):
  dictAccum={}
  for i in dictData:
    if keyValues in i:
      v=i[keyValues]
      dictAccum[v]=0
  return dictAccum
  
def total_matches(lod,k,v):
  dictAccum=0
  for dic in lod:
    if dic[k]==v:
      dictAccum=dictAccum+1
  return dictAccum
  
def total_matches_specific(lod,k,v,k2,v2):
  accum=0
  for dic in lod:
    if (dic[k]==v) and (dic[k2]==v2):
      accum+=1
  return accum 

def remove_min(dictionary,integer):
  newDic={}
  for i in dictionary.keys():
    if dictionary[i]>integer:
      newDic[i]=dictionary[i]
  return newDic
  