// Functions that create the charts using Plotly
function loadChart(){
  ajaxGetRequest("/barChart",Bar)
  ajaxGetRequest("/pieChart",Pie)
}




function Bar(Get){
  Plotly.newPlot("barChart", JSON.parse(Get))
}
function Pie(Get){
  Plotly.newPlot("pieChart", JSON.parse(Get))
}
function Line(Get){
  Plotly.newPlot("lineChart", JSON.parse(Get))
}

function HourData(){
  let temp = document.getElementById("input").value
  ajaxPostRequest('/lineChart',temp,Line)
}