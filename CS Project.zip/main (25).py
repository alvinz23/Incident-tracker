import bottle
import json
import data 
import process 
import os.path

def startup( ): 
  csv_file = 'saved_data.csv'
  if not os.path.isfile(csv_file):
    url = 'https://data.buffalony.gov/resource/d6g9-xbgu.json?$limit=50000'
    info = data.json_loader(url)
    data.fix_data(info,"incident_datetime")
    heads = ['year','month','hour_of_day','incident_type_primary','day_of_week']
    data.save_data(info, heads, csv_file)
startup()

csv_loader = data.load_data("saved_data.csv")


@bottle.route("/") e 
def index():
  html_file = bottle.static_file("index.html", root= ".")
  return html_file

@bottle.route("/charts.js") 
def charts():
  charts_file = bottle.static_file("charts.js", root = ".")
  return charts_file

@bottle.route("/ajax.js")  
def ajax():
  ajax_file = bottle.static_file("ajax.js", root= ".")
  return ajax_file

@bottle.route("/barChart") 
def bar(): 
  dictionary = process.gen_dictionary(csv_loader, "year") 
  for index in dictionary:
    dictionary[index] = process.total_matches(csv_loader, "year", index)
  dictionary = process.remove_min(dictionary,20) # 
  return json.dumps([{
    "x": list(dictionary.keys()), 
    "y": list(dictionary.values()), 
    "type": "bar",
    "title": "Incidents by Year"
  }])

@bottle.route("/pieChart") 
def pie():
  newDict = process.gen_dictionary(csv_loader, "day_of_week")
  for index in newDict:
    newDict[index] = process.total_matches(csv_loader, "day_of_week", index)
  newDict = process.remove_min(newDict, 20) 
  return json.dumps([{
    "labels": list(newDict.keys()),
    "values": list(newDict.values()),
    "type": "pie",
    "title": "Incidents by Day of Week",
  }])


@bottle.post("/lineChart") 
def line(): 
  req = bottle.request.body.read().decode()
  dictionary = process.gen_dictionary(csv_loader, "year")
  for index in dictionary:
    dictionary[index] = process.total_matches_specific(csv_loader, "year", index, "hour_of_day", req)
  x = []
  y = []
  for keys in dictionary.keys():
    x.append(keys)
  x.sort()
  for j in x:
    y.append(dictionary[j])
  return json.dumps([{
    "x": x,
    "y": y,
    "type": "line",
    "markers": True,
    "title": "Number of Incidents at 10 Hundred Hours"
    }])

bottle.run(host="0.0.0.0",port=8080,debug=True)